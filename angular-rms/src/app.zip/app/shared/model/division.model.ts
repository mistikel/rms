export class Division {
    id: number;
    description:string;
    Division() {}
}