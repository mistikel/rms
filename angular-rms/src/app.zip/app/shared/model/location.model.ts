export class Location {
    Id: number;
    description:string;
    Location() {}
}