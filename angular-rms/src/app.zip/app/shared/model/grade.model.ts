export class Grade {
    id: number;
    descGrade:string;
    Grade() {}
}