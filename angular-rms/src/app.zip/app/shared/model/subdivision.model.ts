import { Division } from "app/shared/model/division.model";

export class SubDivision {
    id: number;
    description:string;
    division:Division;
    SubDivision() {}
}