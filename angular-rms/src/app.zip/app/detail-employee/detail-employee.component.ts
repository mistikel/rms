import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'app-detail-employee',
	templateUrl: 'detail-employee.component.html',
	styleUrls: ['detail-employee.component.css']
})

export class DeatilEmployeeComponent implements OnInit {
	ngOnInit() { }
}